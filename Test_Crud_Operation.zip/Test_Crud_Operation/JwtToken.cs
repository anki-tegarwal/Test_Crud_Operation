﻿namespace Test_Crud_Operation
{
    public class JwtToken
    {
        public string secret { get; set; }
    }
}
