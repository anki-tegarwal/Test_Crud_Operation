﻿namespace Test_Crud_Operation.Models.ViewModel
{
    public class ReportViewModel
    {
        public string DimensionOne { get; set; }
        public int Quantity { get; set; }
        public string Month { get; set; }
    }
}
