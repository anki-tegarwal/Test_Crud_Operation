﻿namespace Test_Crud_Operation.Models.ViewModel
{
    public class RegisterViewModel
    {
        
        public int Id { get; set; }
        public string Name { get; set; }
        public string Email { get; set; }
        public string Password { get; set; }
        public string PhoneNumber { get; set; }

    }
}
